<?php
    require 'banco.php';

    $sql = "select * from comentarios";

    $consulta = $conexao->prepare($sql);
    
    $consulta->execute();

    $dados = $consulta->fetchAll(PDO::FETCH_OBJ);

    echo json_encode($dados);
?>