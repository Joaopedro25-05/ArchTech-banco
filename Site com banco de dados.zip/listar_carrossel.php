<?php
require 'banco.php';

$sql = "SELECT * FROM carrosel";
$consulta = $conexao->prepare($sql);
$consulta->execute();
$dados = $consulta->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: application/json');
echo json_encode($dados);
?>
