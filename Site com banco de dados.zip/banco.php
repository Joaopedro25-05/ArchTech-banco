<?php
    $conexao = new PDO("mysql:host=localhost;dbname=archtech;charset=utf8", "root", "");
?>