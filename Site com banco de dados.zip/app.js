function salvarContato() {
  let nomeContato = document.getElementById('usuario').value;
  let email = document.getElementById('email').value;
  let comentarioContato = document.getElementById('mensagem').value;

  if (nomeContato && email && comentarioContato) {
    let url = `http://localhost/archtech/contato.php?nome=${nomeContato}&email=${email}&comentario=${comentarioContato}`;
    let req = new XMLHttpRequest();
    req.open('GET', url, false);
    req.send();

    // Verifica se a operação foi bem-sucedida antes de continuar
    let res = JSON.parse(req.responseText);
    if (res.success) {
      console.log('Contato salvo com sucesso!');
      
      // Limpa os campos do formulário após salvar
      document.getElementById('usuario').value = '';
      document.getElementById('email').value = '';
      document.getElementById('mensagem').value = '';

      return false;
    }
  }
}

function listarComentario() { 
  // Monta a URL correta para listar os comentários
  let url = `./listar_comentario.php`;

  let req = new XMLHttpRequest();
  req.open('GET', url, false);
  req.send();

  let res = JSON.parse(req.responseText);
  console.log(res);

  let t = document.getElementById('comentarios');
  t.innerHTML = '';

  for (let i in res) {
    t.innerHTML += `<tr>
      <td><img id="imagem" src="Imagens/${res[i].foto}" alt="Foto"></td>
      <td>${res[i].comentario}</td>
      <td><strong>${res[i].nome}</strong></td>
    </tr>`;
  }
}


function iniciar() {
    listarComentario()
    listarCarrossel()
}

function adicionarComentario() {
    document.getElementById('nome').value = '';
    document.getElementById('comentario').value = '';
}

function salvar() {
  let nome = document.getElementById('nome').value;
  let comentario = document.getElementById('comentario').value;

  let url;

  if (nome !== '') {
    url = `http://localhost/archtech/adicionar_comentario.php?nome=${nome}&comentario=${comentario}`;

    let req = new XMLHttpRequest();
    req.open('GET', url, false);
    req.send();

    // Remova a referência a isValidJson nesta parte
    let res = JSON.parse(req.responseText);
    console.log(res);

    // Chamar a função correta para atualizar a tabela
    listarComentario();

    // Fechar o modal após salvar
    $('#modalExemplo').modal('hide');
  } else {
    console.error('O nome não pode estar vazio.');
  }
}


function listarCarrossel() {
  // Monta a URL correta para listar os itens do carrossel
  let url = `./listar_carrossel.php`;

  let req = new XMLHttpRequest();
  req.open('GET', url, false);
  req.send();

  let res = JSON.parse(req.responseText);
  console.log(res);

  let carouselInner = document.querySelector('.carousel-inner');
  let indicators = document.querySelector('.carousel-indicators');

  carouselInner.innerHTML = '';
  indicators.innerHTML = '';

  for (let i in res) {
    // Adiciona itens ao carrossel
    carouselInner.innerHTML += `<div class="carousel-item${i == 0 ? ' active' : ''}">
        <img class="d-block w-100" src="Imagens/${res[i].imagem}" alt="Slide ${i}">
        <div class="carousel-caption d-none d-md-block">
          <h5>${res[i].titulo}</h5>
          <p>${res[i].descriçao}</p>
        </div>
      </div>`;

    // Adiciona indicadores
    indicators.innerHTML += `<li data-target="#carouselExampleIndicators" data-slide-to="${i}"${i == 0 ? ' class="active"' : ''}></li>`;
  }
}