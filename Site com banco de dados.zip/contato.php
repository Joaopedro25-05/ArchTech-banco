<?php
require 'banco.php';

$nomeContato = $_GET['nome'];
$emailContato = $_GET['email'];
$comentarioContato = $_GET['comentario'];

$sql = "INSERT INTO contato (nome, email, comentario) VALUES (:nome, :email, :comentario)";
$stmt = $conexao->prepare($sql);
$stmt->bindParam(':nome', $nomeContato);
$stmt->bindParam(':email', $emailContato);
$stmt->bindParam(':comentario', $comentarioContato);
$stmt->execute();

echo json_encode(["success" => true]);
?>