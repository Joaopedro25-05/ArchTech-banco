<?php
$comentario = isset($_GET['comentario']) ? $_GET['comentario'] : null;
$nome = isset($_GET['nome']) ? $_GET['nome'] : null;

if ($nome !== null && $comentario !== null) {
    require 'banco.php';

    $sql = "insert into comentarios (nome, comentario) values (:nome, :comentario)";

    $consulta = $conexao->prepare($sql);
    $consulta->bindParam(':nome', $nome, PDO::PARAM_STR);
    $consulta->bindParam(':comentario', $comentario, PDO::PARAM_STR);

    try {
        $consulta->execute();
        $linhas = $consulta->rowCount();

        echo json_encode(['status' => 'success', 'message' => 'Comentário adicionado com sucesso.']);
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Parâmetros ausentes']);
}
?>
