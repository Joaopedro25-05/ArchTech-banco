-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 27/11/2023 às 20:48
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `archtech`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `carrosel`
--

CREATE TABLE `carrosel` (
  `id` int(11) NOT NULL,
  `imagem` varchar(40) NOT NULL,
  `titulo` text NOT NULL,
  `descriçao` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `carrosel`
--

INSERT INTO `carrosel` (`id`, `imagem`, `titulo`, `descriçao`) VALUES
(1, 'formatacaopromocao.png', 'Formatação de computador', 'Promoção Especial 50% off\r\nDe R$80,00 para R$40,00'),
(2, 'diamundialbackup.webp', 'Backup', 'Desconto Imperdível\r\nNa compra do serviço de formatação, leve o serviço backup grátis!!'),
(3, 'combo2_resized.jpg', '', '');

-- --------------------------------------------------------

--
-- Estrutura para tabela `comentarios`
--

CREATE TABLE `comentarios` (
  `foto` varchar(25) DEFAULT NULL,
  `comentario` text NOT NULL,
  `nome` text NOT NULL,
  `id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `comentarios`
--

INSERT INTO `comentarios` (`foto`, `comentario`, `nome`, `id`) VALUES
('Bruno.jpg', 'Excelente trabalho!! Muito pontuais e seguem os prazos.', 'Bruno Sonza Almeida', 1),
('Hanna.jpg', 'Muito bonsss, me ajudaram muito com o meu problema de maneira muito eficiente.', 'Hanna Mansour', 2),
('Sofia.jpg', 'Bom trabalho, porém o atendimento um pouco lento...', 'Sofia Lopes da Silva', 3),
('Gustavo.jpg', 'Excelentes profissionais, excelente site, perfeito.', 'Gustavo Pellá Bazzanella', 4),
('Otávio.jpg', 'Gostei muito do atendimento e a forma que não só resolveram o problema, mas também explicaram o que estava acontecendo para que eu pudesse entender.', 'Otávio Guzzi Guerreiro', 5);

-- --------------------------------------------------------

--
-- Estrutura para tabela `contato`
--

CREATE TABLE `contato` (
  `id` int(30) NOT NULL,
  `nome` text NOT NULL,
  `email` varchar(30) NOT NULL,
  `comentario` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `contato`
--

INSERT INTO `contato` (`id`, `nome`, `email`, `comentario`) VALUES
(1, 'Teste', 'teste@gmail.com', 'hgnf'),
(2, 'João Pedro Guzzi Guerreiro', 'guerreiro2505055@gmail.com', 'Testando');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `carrosel`
--
ALTER TABLE `carrosel`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `comentarios`
--
ALTER TABLE `comentarios`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `contato`
--
ALTER TABLE `contato`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `carrosel`
--
ALTER TABLE `carrosel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `comentarios`
--
ALTER TABLE `comentarios`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `contato`
--
ALTER TABLE `contato`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
